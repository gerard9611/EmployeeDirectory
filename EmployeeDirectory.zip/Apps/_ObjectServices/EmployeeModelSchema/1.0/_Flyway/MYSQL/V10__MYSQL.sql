ALTER TABLE `Media`
	CHANGE `Media_type` `Media_type_id` VARCHAR(50) NOT NULL;
