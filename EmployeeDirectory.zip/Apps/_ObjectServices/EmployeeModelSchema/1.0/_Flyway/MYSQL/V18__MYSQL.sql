ALTER TABLE `Employee`
	MODIFY `First_name` VARCHAR(32);
